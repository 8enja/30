const a = "Razita";
const b = "ganar";
const c = "uffa";
console.log("La " + a + " no se cansa de " + b + ", " + c + ".");
