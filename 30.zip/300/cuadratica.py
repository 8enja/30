import math
def cuadratica():
    dio_resultado = False
    print("##### ECUACIÓN CUADRÁTICA #####")
    
    while dio_resultado == False:
        try:
            numeros = input("Ingresa los valores de A, B y C separados por espacios: ").split()

            if len(numeros) != 3:
                print("Ingresa 3 valores")
                
            else:
                a = int(numeros[0])
                b = int(numeros[1])
                c = int(numeros[2])
                casita = pow(b,2) - (4*a*c)
                
                if casita < 0:
                    print("No tiene solución")
                    dio_resultado = True
                    
                elif casita == 0:
                    x = -b / (2*a)
                    if x % 1 == 0:
                        x = int(x)
                    else:
                        x = round(x, 2) 
                    print("x= ", x)
                    dio_resultado = True  
                    
                else:
                    x1 = (-b + math.sqrt(casita))/(2*a)
                    if x1 % 1 == 0:
                        x1 = int(x1)
                    else:
                        x1 = round(x1, 2)
                        
                    x2 = (-b - math.sqrt(casita))/(2*a)
                    if x2 % 1 == 0:
                        x2 = int(x2)
                    else:
                        x2 = round(x2, 2)
                        
                    print("x1 = ", x1)
                    print("x2 = ", x2)
                    dio_resultado = True
                    
        except ValueError:
            print("Sólo se aceptan números")
   
        except ZeroDivisionError:
            print("No es una ecuación cuadrática")
            dio_resultado = True
     
        
cuadratica()
        
# IndexError
# ZeroDivisionError
# ValueError   
