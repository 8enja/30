import random

data =[]
for i in range(10):
    data.append(random.randint(0,100))

print(data)


def insertion_sort(data):
    for i in range(1,len(data)):
        key = data[i]
        j = i-1
        while j >= 0 and key < data[j]:
            data[j+1] = data[j]
            j -= 1
        data[j+1] = key
    return data

print(insertion_sort(data))