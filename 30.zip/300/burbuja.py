import random

data =[]
for i in range(10):
    data.append(random.randint(0,100))

print(data)




def burbuja(data):
    for i in range(len(data)):
        for j in range(len(data)-1):
            if data[j] > data[j+1]:
                data[j],data[j+1] = data[j+1],data[j]
    return data

print(burbuja(data))